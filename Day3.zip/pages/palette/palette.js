//index.js
//获取应用实例
import ColorThief from '/utils/color-thief.js'
import {
  rgbToHex,
  uuid,
  colorsEqual,
  saveBlendent
} from '/utils/util.js'
const app = getApp()
Page({
  data: {
    colorThief: '',
    imgPath: 'cloud://cloud1-6gr4hx811cc64b6a.636c-cloud1-6gr4hx811cc64b6a-1307900125/image/02095115.jpg',
    colors: [
    ],
    imgInfo: {},
    colorCount: 5,
    screenWidth: 0
  },
  chooseImg: function () {
    var that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        that.setData({
          imgPath: res.tempFilePaths[0],
        })
        wx.getImageInfo({
          src: 'that.data.imgPath',
          success: function (imgInfo) {

          }
        })
        wx.getImageInfo({
          src: that.data.imgPath,
          success: (imgInfo) => {
            let {
              width,
              height,
              imgPath
            } = imgInfo;
            let scale = 0.8 * that.data.screenWidth / Math.max(width, height);
            let canvasWidth = Math.floor(scale * width);
            let canvasHeight = Math.floor(scale * height);
            that.setData({
              imgInfo,
              canvasScale: scale,
              canvasWidth,
              canvasHeight
            });
            let quality = 1;
            that.data.colorThief.getPalette({
              width: canvasWidth,
              height: canvasHeight,
              imgPath: res.tempFilePaths[0],
              colorCount: that.data.colorCount,
              quality
            }, (colors) => {
              if (colors) {
                colors = colors.map((color) => {
                  return ('#' + rgbToHex(color[0], color[1], color[2]))
                })
                that.setData({
                  colors,
                })
              }
            });
          }
        })
      }
    })
  },
  onLoad: function () {
    var that = this
    that.data.colorThief = new ColorThief('imageHandler');
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          screenWidth: res.windowWidth
        })
        wx.getImageInfo({
          src: that.data.imgPath,
          success: (imgInfo) => {
            let width = imgInfo.width
            let height = imgInfo.height
            let imgPath = imgInfo.path
            let scale = 0.8 * that.data.screenWidth / Math.max(width, height);
            let canvasWidth = Math.floor(scale * width);
            let canvasHeight = Math.floor(scale * height);
            that.setData({
              imgInfo,
              canvasScale: scale,
              canvasWidth,
              canvasHeight,
              imgPath: imgPath
            });
            let quality = 1;
            that.data.colorThief.getPalette({
              width: canvasWidth,
              height: canvasHeight,
              imgPath: that.data.imgPath,
              colorCount: that.data.colorCount,
              quality
            }, (colors) => {
              if (colors) {
                colors = colors.map((color) => {
                  return ('#' + rgbToHex(color[0], color[1], color[2]))
                })
                that.setData({
                  colors,
                })
              }
            });
          }
        })
      },
    })
  }
})